import { Estado, TipoArchivo } from "./types";

export default class Archivo<T> {
  id: number;
  nombre: string;
  tipo: TipoArchivo;
  contenido: T;
  estado: Estado = "activo";

  constructor(id: number, nombre: string, tipo: TipoArchivo, contenido: T) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.contenido = contenido;
  }

mostrarInfo(): string {
  return `[${this.tipo}] ${this.nombre} (Estado: ${this.estado})`;
}


  eliminar() {
    this.estado = "eliminado";
  }
}