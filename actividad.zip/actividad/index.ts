import { input, select } from "@inquirer/prompts";
import Carpeta from "./Carpeta";
import Archivo from "./Archivo";
import { TipoArchivo } from "./types";

const carpetaPrincipal = new Carpeta("Mis Archivos");

while (true) {
  const option = await select({
    message: "📂 Gestor de Archivos",
    choices: [
      { name: "➕ Crear Archivo", value: "crear" },
      { name: "📋 Listar Archivos", value: "listar" },
      { name: "🗑 Eliminar Archivo", value: "eliminar" },
      { name: "🚪 Salir", value: "salir" },
    ],
  });

  if (option === "crear") {
    const nombre = await input({ message: "📄 Nombre del archivo:" });
    const tipo = await select({
      message: "📌 Tipo de archivo",
      choices: [
        { name: "📄 Documento", value: "📄 Documento" },
        { name: "🖼 Imagen", value: "🖼 Imagen" },
        { name: "🎵 Audio", value: "🎵 Audio" },
        { name: "🎬 Video", value: "🎬 Video" },
      ],
    });

    const contenido = await input({ message: "✏ Contenido del archivo:" });

    const archivo = new Archivo(
      carpetaPrincipal.archivos.length + 1,
      nombre,
      tipo as TipoArchivo,
      contenido
    );
    carpetaPrincipal.agregarArchivo(archivo);

    console.log("✅ Archivo creado con éxito!");
  }

  if (option === "listar") {
    console.log(carpetaPrincipal.listarArchivos());
  }

  if (option === "eliminar") {
    const nombre = await input({ message: "🗑 Nombre del archivo a eliminar:" });
    const archivo = carpetaPrincipal.archivos.find((a) => a.nombre === nombre);

    if (archivo) {
      archivo.eliminar();
      console.log("🗑 Archivo eliminado.");
    } else {
      console.log("⚠ Archivo no encontrado.");
    }
  }

  if (option === "salir") {
    console.log("👋 Saliendo del gestor...");
    break;
  }
}
