// --- TYPE normales y con unión ---
export type Estado = "activo" | "eliminado";
export type TipoArchivo = "📄 Documento" | "🖼 Imagen" | "🎵 Audio" | "🎬 Video";