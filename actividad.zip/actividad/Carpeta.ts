import Archivo from "./Archivo";

export default class Carpeta {
  nombre: string;
  archivos: Archivo<any>[] = [];

  constructor(nombre: string) {
    this.nombre = nombre;
  }

  agregarArchivo(archivo: Archivo<any>) {
    this.archivos.push(archivo);
  }

  listarArchivos() {
    if (this.archivos.length === 0) {
      return "📂 Carpeta vacía";
    }
    return this.archivos.map((a) => a.mostrarInfo()).join("\n");
  }
}